// ignore_for_file: camel_case_types

import 'dart:ui';
import 'package:flutter/material.dart';
import 'color.dart';
class Wallet extends StatelessWidget {
  const Wallet({Key? key}) : super(key: key);

  get actions => null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          elevation: 0,
          leading: Image.asset(
            "assets/images/menu.png",
            color: Colors.white,
            height: 1,
          ),
          title: const Text(
            'WALLET',
            style: TextStyle(
                fontSize: 20, fontFamily: "Gras", fontWeight: FontWeight.bold),
          ),
          backgroundColor: HexColor("90A7B4"),
          centerTitle: true,
          actions: <Widget>[
            IconButton(
              icon: const Icon(Icons.notifications_active),
              onPressed: () => {print("Click on upload button")},
            ),
          ]),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: 80,
              width: double.infinity,
              decoration: BoxDecoration(
                color: HexColor("90A7B4"),
                borderRadius: const BorderRadius.only(
                    bottomRight: Radius.circular(20),
                    bottomLeft: Radius.circular(20)),
              ),
              child: Column(
                children: [
                  Container(
                      height: 50,
                      decoration: BoxDecoration(
                        color: HexColor("90A7B4"),
                        borderRadius: const BorderRadius.only(),
                      ),
                      child: Column(
                        children: const [
                          Text(
                            "\$26\,072.00",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 35,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            "Ricardo et landry",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 7,
                            ),
                          ),
                        ],
                      ))
                ],
              ),
            ),
            Container(
              child: Row(
                children: [
                  Image.asset(
                    "assets/images/loupe.png",
                    color: Colors.white,
                    height: 20,
                  ),
                  const SizedBox(
                    width: 290,
                  ),
                  Image.asset(
                    "assets/images/help.png",
                    color: Colors.white,
                    height: 25,
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 5,
            ),
            Container(
              margin: const EdgeInsets.fromLTRB(35, 10, 35, 10),
              padding: const EdgeInsets.all(20.0),
              height: 110,
              color: HexColor("525F67"),
              child: Row(
                children: [
                  Image.asset(
                    "assets/images/bitcoin.png",
                    height: 50,
                  ),
                  Column(
                    children: const [
                      Text(
                        "BTC",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 35,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        "Bitcoin",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                      Text(
                        "************523",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    width: 28,
                  ),
                  Column(
                    children: const [
                      Text(
                        "\$1 845.80",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 25,
                        ),
                      ),
                      Text(
                        "+3%",
                        style: TextStyle(
                          color: Color(0xff69F0AE),
                          fontSize: 12,
                        ),
                      ),
                      Text(
                        "Changes",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
            Container(
              margin: const EdgeInsets.fromLTRB(35, 10, 35, 10),
              padding: const EdgeInsets.all(20.0),
              height: 110,
              color: HexColor("525F67"),
              child: Row(
                children: [
                  Image.asset(
                    "assets/images/ethereum.png",
                    height: 50,
                  ),
                  Column(
                    children: const [
                      Text(
                        "ETH",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 35,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        "Ethereum",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                      Text(
                        "************698",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    width: 45,
                  ),
                  Column(
                    children: const [
                      Text(
                        "\$3 525.98",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 25,
                        ),
                      ),
                      Text(
                        "+0.07%",
                        style: TextStyle(
                          color: Color(0xffD8392B),
                          fontSize: 12,
                        ),
                      ),
                      Text(
                        "Changes",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
            Container(
              margin: const EdgeInsets.fromLTRB(35, 10, 35, 10),
              padding: const EdgeInsets.all(20.0),
              height: 110,
              color: HexColor("525F67"),
              child: Row(
                children: [
                  Image.asset(
                    "assets/images/dash.png",
                    height: 50,
                  ),
                  Column(
                    children: const [
                      Text(
                        "DASH",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 35,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        "Digital Cash",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                      Text(
                        "************198",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    width: 40,
                  ),
                  Column(
                    children: const [
                      Text(
                        "\$525.98",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 25,
                        ),
                      ),
                      Text(
                        "+8%",
                        style: TextStyle(
                          color: Color(0xff69F0AE),
                          fontSize: 12,
                        ),
                      ),
                      Text(
                        "Changes",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
            Container(
              margin: const EdgeInsets.fromLTRB(35, 10, 35, 10),
              padding: const EdgeInsets.all(20.0),
              height: 110,
              color: HexColor("232B2E"),
              child: Row(
                children: [
                  Column(
                    children: [
                      Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          color:  HexColor("69F0AE"),
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: Column(
                          children: [
                            const SizedBox(
                              height: 2,
                            ),
                            Image.asset(
                              "assets/images/add.png",
                              height: 40,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(
                        height: 3,
                      ),
                      const Text(
                        "ADD FUNDS",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    width: 40,
                  ),
                  Column(
                    children: [
                      Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: Column(
                          children: [
                            const SizedBox(
                              height: 5,
                            ),
                            Image.asset(
                              "assets/images/expand.png",
                              height: 30,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(
                        height: 3,
                      ),
                      const Text(
                        "FREEZE",
                        style: TextStyle(color: Colors.white),
                      ),
                    ],
                  ),
                  const SizedBox(
                    width: 50,
                  ),
                  Column(
                    children: [
                      Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: Column(
                          children: [
                            const SizedBox(
                              height: 5,
                            ),
                            Image.asset(
                              "assets/images/security.png",
                              height: 30,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      const Text(
                        "SECURITY",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.all(20.0),
              height: 100,
              decoration: BoxDecoration(
                color: HexColor("B0B7BF"),
                borderRadius: const BorderRadius.only(
                    topRight: Radius.circular(20),
                    topLeft: Radius.circular(20)),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    "PRICE GRAPH",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Container(
                        width: 50,
                        height: 20,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          children: const [Text("DAY")],
                        ),
                      ),
                      const SizedBox(
                        width: 15,
                      ),
                      Container(
                        width: 50,
                        height: 20,
                        decoration: BoxDecoration(
                          color: HexColor("69F0AE"),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          children: const [Text("WEEK")],
                        ),
                      ),
                      const SizedBox(
                        width: 15,
                      ),
                      Container(
                        width: 55,
                        height: 20,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          children: const [Text("MONTH")],
                        ),
                      ),
                      const SizedBox(
                        width: 15,
                      ),
                      Container(
                        width: 50,
                        height: 20,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          children: const [Text("YEAR")],
                        ),
                      ),
                      const SizedBox(
                        width: 15,
                      ),
                      Container(
                        width: 50,
                        height: 20,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          children: const [Text("RANGE")],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
          showSelectedLabels: true,
          showUnselectedLabels: false,
          backgroundColor: HexColor("B0B7BF"),
          items: [
            BottomNavigationBarItem(
              icon: Image.asset(
                "assets/images/wallet.png",
                height: 30,
                color: Colors.white,
              ),
              label: "",
            ),
            BottomNavigationBarItem(
              icon: Image.asset(
                "assets/images/plus.png",
                height: 30,
                color: Colors.white,
              ),
              label: "",
            ),
            BottomNavigationBarItem(
              icon: Image.asset(
                "assets/images/shuffle.png",
                height: 30,
                color: Colors.white,
              ),
              label: "",
            ),
          ]),
    );
  }
}